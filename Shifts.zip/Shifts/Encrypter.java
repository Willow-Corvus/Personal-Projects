public class Encrypter {
    // Amount of times to encrypt
    private int amount;

    // String to be encrypted
    public static String starting;

    // Arrays for the use of encryption
    private String[] temp1;
    private String[] temp2;

    // The alphabet as an array for ease of encryption
    private String[] alph = {"a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"};

    // Constructer
    public Encrypter(String start, int amnt){
        amount = amnt;
        starting = start;
        temp1 =  new String[starting.length()];
        temp2 =  new String[starting.length()];
    }

    // Converts the string into an array
    public void convert(){
        for (int i = 0; i < starting.length(); i++){
            temp1[i] = starting.substring(i, i+1);
            
        }
    }
    
    // The actual encryption
    public String[] encrypt(){
        for (int i = 0; i < temp1.length; i++){
            // Checks for a blank character to prevent infinite loops
            if (temp1[i].equals(" ")){
                temp2[i] = " ";
            }
            else{
                // Checks for where a letter is in the alphabet
                int b = 0;
                while (true){
                    if (alph[b].equalsIgnoreCase(temp1[i])){
                        break;
                    }
                    else{
                        b++;
                    }
                }

                // Checks if going three letters down goes out of bounds
                if (b + amount > 25){
                    b = (b + (amount - 1)) - 25;
                }
                else{
                    b += amount;
                }
                // Pushses the encrypted letter to the encrypted array
                temp2[i] = alph[b];
            }
        }
        return temp2;
    }

}