public class ArraytoString {
    String[] array;
    String finalMes = "";

    

    public ArraytoString(String[] array) {
        this.array = array;
    }

    public String mesig(){
        for(int i = 0;i<array.length;i++){
            finalMes += array[i];
        }
        return finalMes;
    }

    public String[] getArray() {
        return array;
    }
    public void setArray(String[] array) {
        this.array = array;
    }
    public String getFinalMes() {
        return finalMes;
    }
    public void setFinalMes(String finalMes) {
        this.finalMes = finalMes;
    }

    @Override
    public String toString() {
        return "Encrypted Message = " + finalMes;
    }

}
