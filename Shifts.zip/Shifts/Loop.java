import java.util.*;
public class Loop {
    static Scanner in = new Scanner(System.in);
    private static int key = 0;

    public static void loopEncrpt(String crack,int amount){
        String attempt = crack;
        for(int i = 0;i<amount;i++){
            if(i % 2 == 0){
                int enct =(int)(Math.random() *(10-1+1))+1;
                Encrypter code = new Encrypter(attempt,enct);
                code.convert();
                ArraytoString temp = new ArraytoString(code.encrypt());
                attempt = temp.mesig();
            }
            else{
                int enct =(int)(Math.random() *(10-1+1))+1;
                Decryption x = new Decryption(enct,attempt);
                attempt = x.decodeMessage();
            }
        }
        System.out.println("Your final code Message is : " + attempt);
    }

    public static void loopHardDecrept(String crack){
        key = 0;
        String attempt = crack;
        while(true){
            Decryption x = new Decryption(1,attempt);
            attempt = x.decodeMessage();
            key++;
            System.out.println(attempt + "\nIs this the message?");
            String ask = in.nextLine();
            if(ask.toLowerCase().equals("yes")){
                System.out.println("Your message was : " + attempt + "\nThe key was : " + key);
                break;
            }
        }
    }

    public static void loopHardKeyDecrept(String crack){
        String temp = Encrypter.starting;
        key = 0;
        String attempt = crack;
        while(temp.toLowerCase().equals(attempt)==false){
            Decryption x = new Decryption(1,crack);
            attempt = x.decodeMessage();
            key++;
        }
        System.out.println("Your message was : " + attempt + "\nThe key was : " + key);
    }
    
}
