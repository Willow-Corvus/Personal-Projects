
public class Decryption {
    private String[] alpha = {"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"};
    //The alphabet in a  list
    private int key;
    //How much the code has been shifted by
    private String code;
    //Encoded Message
    private String message = "";
    //Decoded Message
    public Decryption(int key, String code) {
        this.key = key;
        this.code = code;
    }

    public String decodeMessage(){
        for(int i = 0; i< code.length();i++){
            //Loops over the message
            boolean check = false;
            //Check statment to see if there is a non alphabetical character
            for(int j = 0; j<alpha.length; j++){
                //loops over the list
                if(code.substring(i, i+1).toLowerCase().equals(alpha[j])){
                    //Checks if the character is in the array
                    if(j-key>=0){
                        message += alpha[j-key];
                        //Adds the character to final message
                        check = true;
                        //Tells teh check statment that there is no non alpha characters
                        break;
                    }
                    else{
                        message += alpha[alpha.length-key];
                        //Checks if the character is in the array
                        check = true;
                        //Tells the check statment there is no non alpha characters
                        break;
                    }
                }
               
            }
            if(check == false){
                //Checks if there is any non alpha characters
                message += code.substring(i, i+1);
                //Adds the non alpha or transmultable characters
            }
        }
        return message;
        //Returns final message
    }

    public String[] getAlpha() {
        return alpha;
    }

    public int getKey() {
        return key;
    }

    public void setKey(int key) {
        this.key = key;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public void setAlpha(String[] alpha) {
        this.alpha = alpha;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return "Decryption key = " + key + "\nCode = " + code + "\nMessage = " + message ;
    }
}
