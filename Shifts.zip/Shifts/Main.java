import java.util.*;

public class Main {
    public static void main(String[] args){
        Scanner in = new Scanner(System.in);
        try{

            System.out.println("Ceaser Shifts");
            while(true){
                System.out.println("Do you know what a Ceaser Shift is?\nYes or No");
                String word = in.nextLine(); 
                if(word.toLowerCase().equals("yes")){
                    break;
                }else{
                System.out.println("A Ceaser Shift is a message where you shift a alphabet by a key for you message\nExample : \n");
                Encrypter code = new Encrypter("a b c d e f g h i j k l m n o p q r s t u v w x y z", 5);
                code.convert();
                System.out.println("Encrypted: ");
                ArraytoString temp = new ArraytoString(code.encrypt());
                System.out.println("a b c d e f g h i j k l m n o p q r s t u v w x y z");
                System.out.println(temp.mesig());
                System.out.println("This is what a shifted alphabet looks like the key is 5");
                }
            }
            //Intro to Ceaser Shifts
            while(true){

                System.out.println("What would you like to do type a number:");
                System.out.println("1 - Encrypt a message with a known key");
                System.out.println("2 - Encrypt a message with a unknown key");
                System.out.println("3 - Find the shift key");
                System.out.println("4 - Dencrypt a message with a known key");
                System.out.println("5 - Dencrypt a message with a unknown key");
                System.out.println("0 - Leave");
                
                int menu = in.nextInt();

                if(menu == 0){
                    break;
                }
                //Ends the menu loop
                if(menu == 1){
                    System.out.println("Enter what to encrypt: ");
                    in.nextLine();
                    String word = in.nextLine(); 
                    System.out.println("Enter far you want to encrypt: ");
                    int amount = in.nextInt();
                    Encrypter code = new Encrypter(word, amount);
                    code.convert();
                    System.out.println("Encrypted: ");
                    ArraytoString temp = new ArraytoString(code.encrypt());
                    System.out.println(temp.mesig());
                
                }
                //Encrypts a message based off a key
                if(menu == 2){
                    System.out.println("What is your message: ");
                    in.nextLine();
                    String tbd = in.nextLine();
                    System.out.println("How many times do you want to mix the message up: ");
                    int shifts = in.nextInt();
                    Loop.loopEncrpt(tbd, shifts);
                }
                //Encrypts a message at random
                if(menu == 3){
                    System.out.println("What is your original message: ");
                    in.nextLine();
                    String word = in.nextLine();
                    Encrypter code = new Encrypter(word, 0);
                    code.convert();
                    System.out.println("What is your coded message: ");
                    String message = in.nextLine();
                    Loop.loopHardKeyDecrept(message);
                }
                //Finds the Key if you have a message that is encoded and the original message
                if(menu == 4){
                    System.out.println("What is your coded message: ");
                    in.nextLine();
                    String code = in.nextLine();
                    System.out.println("What is the key: ");
                    int key = in.nextInt();
                    Decryption decr = new Decryption(key, code);
                    decr.decodeMessage();
                    System.out.println(decr.toString());
                }
                //Decodes the message with a key
                if(menu == 5){
                    System.out.println("What is your coded message: ");
                    in.nextLine();
                    String code = in.nextLine();
                    Loop.loopHardDecrept(code);
                }
                //Decodes the message without a key
            }
        }
        finally{
            in.close();
            //Closes the scanner
        }
    } 
}
