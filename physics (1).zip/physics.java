public class physics
{
    public static void main(String[] args)
    {
        
    }
}