public class physicsCalc {
    public double finalV(double v1, double a, double t){
        return a*t + v1; 
    }
    public intialV(double v2, double a, double t){
        return v2 - (a * t);
    }
    public time(double v1, double v2,double a){
        return (v2 - v1) / a;
    }
    public accelration(double v1, double v2, double t){
        return (v2 - v1) / t;
    }
    public positionFinal(double x1, double v1, double a, double t){
        return x1 + v1 + 1/2*a * Math.pow(t, 2);
    }
    public positionIntial(double x2, double v1, double a, double t){
        return v1 + 1/2*a * Math.pow(t, 2) - x2;
    }
    public velocityNoIntial(double x2, double a, double t, double x1){
        return ((x1 - x2) - .5 * a * Math.pow(t, 2)) / t;
    public accelerationNoTime(double x1, double x2, double v1, double v2){
        return (Math.pow(v2, 2) - Math.pow(v1, 2) / 2) / (x2 - x1);
    }
    public velocityNoAcceleration(double v1, double x1, double x2, double t){
        return v1 + ((((x1 - x2) / t) - v1) / t) * t;
    }
    public positionFinalNoTime(double v1, double v2, double a, double x1){
        return ((Math.pow(v2, 2) - Math.pow(v1, 2)) / 2*a) + x1;
    }
    public positionStartNoTime(double v1, double v2, double a, double x2){
        return (((Math.pow(v2, 2) - Math.pow(v1, 2)) / 2*a) + x2) / -1;
    }
    public totalDistance(double x1 , double x2){
        return x2 - 
    }
}