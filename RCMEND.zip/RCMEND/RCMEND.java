import java.util.*;
import java.util.concurrent.TimeUnit;
public class RCMEND {
    public static void main(String[] arg){
        Scanner in = new Scanner(System.in);
        try{
            ask x = new ask();
            int r = 0;
            while(x.isP()==true){
                System.out.println("Will you right me a letter of recomendation?");
                String o = in.nextLine();
                x.awnser(o);
                if(x.isP()==false){
                    break;
                }
            }
            System.out.println("Thank you for your input");
            for(int i=0;i<100;i++){
                try {
                    TimeUnit.SECONDS.sleep(1);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println("\033[H\033[2J");
                if(r%2==0){
                    System.out.println("<o/\n | \n ^");
                }
                if(r%2==1){
                    System.out.println("\\o>\n | \n ^");
                }
                r++;
                

            }
        }
        finally{
        in.close();
        }
    }
}
