public class ask{
    private boolean p = true;
    public boolean isP() {
        return p;
    }
    public void setP(boolean p) {
        this.p = p;
    }
    public void awnser(String awnser) {
        if(awnser.equals("yes")){
            System.out.println("Thank you for your time");
            p = false;
        }
        else if(awnser.equals("Yes")){
            System.out.println("Thank you for your time");
            p = false;
        }
        else if(awnser.equals("true")){
            System.out.println("Thank you for your time");
            p = false;
        }
        else if(awnser.equals("True")){
            System.out.println("Thank you for your time");
            p = false;
        }
        else if(awnser.equals("no")){
            System.out.println("Thank you for your time\n May I know why?");
            p = false;
        }
        else if(awnser.equals("false")){
            System.out.println("Thank you for your time\n May I know why?");
            p = false;
        }
        else if(awnser.equals("No")){
            System.out.println("Thank you for your time\n May I know why?");
            p = false;
        }
        else if(awnser.equals("False")){
            System.out.println("Thank you for your time\n May I know why?");
            p = false;
        }
        else {
            p = true;
        }
    }
    

}